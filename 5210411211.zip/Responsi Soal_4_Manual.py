import cv2 as cv
import numpy as np

sample = cv.imread('uang 100rb.jpg')
img = cv.resize(sample, (852, 480), interpolation=cv.INTER_AREA)

row_len = len(img)
col_len = len(img[0])

gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

scalar = 30

for row in range(row_len):
    for col in range(col_len):
        pixel = gray[row, col] + scalar
        if pixel > 255:
            gray[row, col] = 255
        else:
            gray[row, col] = pixel

gray = gray.astype(np.uint8)
print(gray)

cv.imshow("gray",gray)
cv.waitKey()