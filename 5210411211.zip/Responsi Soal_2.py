import cv2
import numpy as np
import matplotlib.pyplot as plt

gambar = cv2.imread('uang 100rb.jpg')

# #Split channel manual
b = gambar[:,:,0]
g = gambar[:,:,1]
r = gambar[:,:,2]


#untuk menghitung pixel gray
jml_baris = len(gambar)
jml_kolom = len(gambar[0])
hist_b = np.zeros(256)
hist_g = np.zeros(256)
hist_r = np.zeros(256)

for brs in range(len(gambar)):
    for klm in range(len(gambar[0])):
        pixel = b[brs,klm]
        hist_b[pixel] += 1 / (jml_baris*jml_kolom)

        pixel = g[brs,klm]
        hist_g[pixel] += 1 / (jml_baris*jml_kolom)

        pixel = r[brs,klm] 
        hist_r[pixel] += 1 / (jml_baris*jml_kolom)

plt.plot(hist_b,color = (0,0,1))
plt.plot(hist_g,color = (0,1,0))
plt.plot(hist_r,color = (1,0,0))
plt.show()

cv2.imshow('gambar',gambar) 
cv2.waitKey()