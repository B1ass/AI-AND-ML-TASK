import cv2
import numpy as np

gambar = cv2.imread('uang 100rb.jpg')

# #Split channel manual
b = gambar[:,:,0]
g = gambar[:,:,1]
r = gambar[:,:,2]

jml_baris = len(b)
jml_kolom = len(b[0])
gray = np.zeros((jml_baris,jml_kolom))

for brs in range(jml_baris):
    for klm in range(jml_kolom):
        gray[brs,klm] = round((0.29*r[brs,klm] + 0.59*g[brs,klm] + 0.11*b[brs,klm]) / 3)

gray = gray.astype(np.uint8)
print(gray)

cv2.imshow("gray",gray)
cv2.waitKey()