import cv2 as cv
import numpy as np

sample = cv.imread('uang 100rb.jpg')
img = cv.resize(sample, (852, 480), interpolation=cv.INTER_AREA)

row_len = len(img)
col_len = len(img[0])

sample = cv.cvtColor(sample, cv.COLOR_BGR2GRAY)

scalar = 30

gray = cv.add(sample,scalar)
gray = gray.astype(np.uint8)
print(gray)

cv.imshow("gray",gray)
cv.waitKey()