import cv2
  
gambar = cv2.imread('uang 100rb.jpg')
grayImage = cv2.cvtColor(gambar, cv2.COLOR_BGR2GRAY)
  
(thresh, blackAndWhiteImage) = cv2.threshold(grayImage, 160, 255, cv2.THRESH_BINARY)
 
cv2.imshow('Grayscale image',grayImage)
cv2.imshow('Black white image', blackAndWhiteImage)
  
cv2.waitKey()